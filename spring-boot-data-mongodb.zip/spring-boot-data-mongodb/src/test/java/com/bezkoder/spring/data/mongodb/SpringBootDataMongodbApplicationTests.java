package com.bezkoder.spring.data.mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
